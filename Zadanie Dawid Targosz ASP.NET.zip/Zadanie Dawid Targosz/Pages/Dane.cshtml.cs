using Microsoft.AspNetCore.Mvc.RazorPages;
using hihi.Models;
using System.Collections.Generic;

namespace hihi.Pages
{
    public class DaneModel : PageModel
    {

        public static List<Dane> WprowadzoneDane { get; set; } = new List<Dane>();

        public void OnGet()
        {

        }

        public static void DodajDane(Dane dane)
        {
            WprowadzoneDane.Add(dane);
        }
    }
}
